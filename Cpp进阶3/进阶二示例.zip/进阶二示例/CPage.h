#ifndef __PAGE__
#define __PAGE__

#include <fstream>

#include "graph.h"
#include "rect.h"
#include "circle.h"
#include "circlerect.h"

class CPage{

private :
    CGraph* pGraphs[100];
    int NumGraphs;

public:
    CPage();
    ~CPage();
    void AddGraphs(CGraph* graph);
    void ShowGraphs();
	

     void Save(fstream& file);

     void Load(fstream& file);

};

#endif
