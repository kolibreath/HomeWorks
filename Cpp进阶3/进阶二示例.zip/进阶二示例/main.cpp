#include <iostream>
#include <fstream>
#include "graph.h"
#include "rect.h"
#include "circle.h"
#include "circlerect.h"
#include "cpage.h"
using namespace std;


int main()
{   
    Point point1(3,4);

    CRect* rect = new CRect(point1,1,3,4,5);
   // rect.ShowMsg();
    CCircle* circle = new CCircle(point1,3,4,5);
   // circle.ShowMsg();
    CCircleRect* circleRect = new CCircleRect(*rect,*circle,2,3);
   // circleRect.ShowMsg();

    CPage page;
        page.AddGraphs(rect);
        page.AddGraphs(circle);
        page.AddGraphs(circleRect);

	cout<<"Page Created:"<<endl;
	page.ShowGraphs();

	fstream file ;
	file.open("record.dat",ios::in|ios::out|ios::binary|ios::trunc);
	page.Save(file);
	file.close();

	cout<<"Page Saved:........"<<endl;

	CPage page1;
	file.open("record.dat",ios::in|ios::binary);
	page1.Load(file);
	file.close();

	cout<<"Page1, Loaded:........"<<endl;
	page1.ShowGraphs();



    return 0;
}
