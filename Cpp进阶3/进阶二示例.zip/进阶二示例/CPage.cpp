#include <iostream>
#include "graph.h"
#include "circle.h"
#include "rect.h"
#include "Circlerect.h"
#include "Cpage.h"

using namespace std;

CPage::CPage(){

    NumGraphs = 0;
    for(int i=0;i<100;i++)
        pGraphs[i] = NULL;
}

CPage::~CPage(){

    for(int i=0;i<NumGraphs;i++)
        delete pGraphs[i];
    NumGraphs = 0;
}

void CPage::AddGraphs(CGraph* graph){
    pGraphs[NumGraphs] = graph;
    NumGraphs++;
}

void CPage::ShowGraphs(){

    for(int i=0;i<NumGraphs;i++)
        pGraphs[i]->ShowMsg();
}

void CPage::Save(fstream & file){

	file.write((char*)&NumGraphs,sizeof(NumGraphs));

    for(int i=0;i<NumGraphs;i++)
        pGraphs[i]->Save(file);
}

void CPage::Load(fstream & file){

	int numg = 0;

	file.read((char*)&numg,sizeof(NumGraphs));
	int type,color,lw;
	
	CGraph * g;

	for(int i=0;i<numg;i++){

	   file.read((char*)&type, sizeof(type));
	   file.read((char*)&color, sizeof(color));
	   file.read((char*)&lw, sizeof(lw));
		
	   switch (type){
	   case 1:
		   g = new CCircle(color,lw);
           break;
	   case 2:
		   g = new CRect(color,lw);           
		   break;
	   case 3:
		   g = new CCircleRect(color,lw);          
		   break;
	   }

	  g->Load(file);
	  AddGraphs(g);

	}
       
}