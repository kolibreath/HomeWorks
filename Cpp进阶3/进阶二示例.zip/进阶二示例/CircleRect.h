#ifndef __RECTCIRCLE__
#define __RECTCIRCLE__

#include "graph.h"
#include "rect.h"
#include "circle.h"

class CCircleRect:public CRect,public CCircle{

private :

public:
    CCircleRect(CRect&,CCircle &,int color=0,int linewidth=1);

	CCircleRect(int color=0,int linewidth=1):CGraph(1,color,linewidth){};

    void Show();
    virtual void ShowMsg();

	void Save(fstream& file);

	void Load(fstream& file);

};

#endif
